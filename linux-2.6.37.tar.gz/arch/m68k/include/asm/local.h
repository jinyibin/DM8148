#ifndef _ASM_M68K_LOCAL_H
#define _ASM_M68K_LOCAL_H

#include <asm-generic/local.h>

#endif /* _ASM_M68K_LOCAL_H */
