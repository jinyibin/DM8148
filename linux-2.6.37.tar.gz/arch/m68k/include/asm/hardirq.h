#ifdef __uClinux__
#include "hardirq_no.h"
#else
#include "hardirq_mm.h"
#endif
