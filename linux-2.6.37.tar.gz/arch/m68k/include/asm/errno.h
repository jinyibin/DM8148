#ifndef _M68K_ERRNO_H
#define _M68K_ERRNO_H

#include <asm-generic/errno.h>

#endif /* _M68K_ERRNO_H */
