#ifndef __ASM_M68K_HW_IRQ_H
#define __ASM_M68K_HW_IRQ_H

/* Dummy include. */

#endif
