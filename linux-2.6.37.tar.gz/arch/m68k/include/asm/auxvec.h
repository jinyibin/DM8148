#ifndef __ASMm68k_AUXVEC_H
#define __ASMm68k_AUXVEC_H

#endif
