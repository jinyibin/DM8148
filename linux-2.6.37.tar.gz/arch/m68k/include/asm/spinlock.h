#ifndef __M68K_SPINLOCK_H
#define __M68K_SPINLOCK_H

#error "m68k doesn't do SMP yet"

#endif
