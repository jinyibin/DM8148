#ifndef _ASM_SCORE_UNALIGNED_H
#define _ASM_SCORE_UNALIGNED_H

#include <asm-generic/unaligned.h>

#endif /* _ASM_SCORE_UNALIGNED_H */
