#ifndef _ASM_SCORE_MSGBUF_H
#define _ASM_SCORE_MSGBUF_H

#include <asm-generic/msgbuf.h>

#endif /* _ASM_SCORE_MSGBUF_H */
