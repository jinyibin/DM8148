#ifndef _ASM_SCORE_SOCKET_H
#define _ASM_SCORE_SOCKET_H

#include <asm-generic/socket.h>

#endif /* _ASM_SCORE_SOCKET_H */
