#ifndef _ASM_SCORE_ATOMIC_H
#define _ASM_SCORE_ATOMIC_H

#include <asm-generic/atomic.h>

#endif /* _ASM_SCORE_ATOMIC_H */
