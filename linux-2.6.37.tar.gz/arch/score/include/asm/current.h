#ifndef _ASM_SCORE_CURRENT_H
#define _ASM_SCORE_CURRENT_H

#include <asm-generic/current.h>

#endif /* _ASM_SCORE_CURRENT_H */
