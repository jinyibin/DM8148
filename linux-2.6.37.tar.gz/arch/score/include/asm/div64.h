#ifndef _ASM_SCORE_DIV64_H
#define _ASM_SCORE_DIV64_H

#include <asm-generic/div64.h>

#endif /* _ASM_SCORE_DIV64_H */
