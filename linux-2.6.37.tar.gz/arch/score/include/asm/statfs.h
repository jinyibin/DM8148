#ifndef _ASM_SCORE_STATFS_H
#define _ASM_SCORE_STATFS_H

#include <asm-generic/statfs.h>

#endif /* _ASM_SCORE_STATFS_H */
