#ifndef _ASM_SCORE_KDEBUG_H
#define _ASM_SCORE_KDEBUG_H

#include <asm-generic/kdebug.h>

#endif /* _ASM_SCORE_KDEBUG_H */
