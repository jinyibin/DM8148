#ifndef _ASM_SCORE_SOCKIOS_H
#define _ASM_SCORE_SOCKIOS_H

#include <asm-generic/sockios.h>

#endif /* _ASM_SCORE_SOCKIOS_H */
