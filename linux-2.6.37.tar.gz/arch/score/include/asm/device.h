#ifndef _ASM_SCORE_DEVICE_H
#define _ASM_SCORE_DEVICE_H

#include <asm-generic/device.h>

#endif /* _ASM_SCORE_DEVICE_H */
