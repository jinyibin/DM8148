#ifndef _ASM_SCORE_SHMPARAM_H
#define _ASM_SCORE_SHMPARAM_H

#include <asm-generic/shmparam.h>

#endif /* _ASM_SCORE_SHMPARAM_H */
