#ifndef _ASM_SCORE_LOCAL_H
#define _ASM_SCORE_LOCAL_H

#include <asm-generic/local.h>

#endif /* _ASM_SCORE_LOCAL_H */
