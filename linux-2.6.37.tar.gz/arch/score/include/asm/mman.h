#ifndef _ASM_SCORE_MMAN_H
#define _ASM_SCORE_MMAN_H

#include <asm-generic/mman.h>

#endif /* _ASM_SCORE_MMAN_H */
