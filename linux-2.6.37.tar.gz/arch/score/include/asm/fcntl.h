#ifndef _ASM_SCORE_FCNTL_H
#define _ASM_SCORE_FCNTL_H

#include <asm-generic/fcntl.h>

#endif /* _ASM_SCORE_FCNTL_H */
