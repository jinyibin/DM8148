#ifndef _ASM_SCORE_DMA_H
#define _ASM_SCORE_DMA_H

#include <asm/io.h>

#define MAX_DMA_ADDRESS		(0)

#endif /* _ASM_SCORE_DMA_H */
