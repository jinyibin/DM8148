#ifndef _ASM_SCORE_PCI_H
#define _ASM_SCORE_PCI_H

#endif /* _ASM_SCORE_PCI_H */
