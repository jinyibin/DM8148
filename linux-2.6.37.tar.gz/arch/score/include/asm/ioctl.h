#ifndef _ASM_SCORE_IOCTL_H
#define _ASM_SCORE_IOCTL_H

#include <asm-generic/ioctl.h>

#endif /* _ASM_SCORE_IOCTL_H */
